import 'package:flutter/material.dart';
import 'package:mishwar_app/shared/header_image.dart';
import 'package:mishwar_app/shared/single_news_page.dart';

class NewsPage extends StatefulWidget {
  NewsPage({Key key}) : super(key: key);

  @override
  _NewsPageState createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(240, 240, 240, 1),
        body: CustomScrollView(
          slivers: <Widget>[
            SliverFixedExtentList(
              itemExtent: 160,
              delegate: SliverChildListDelegate(
                [
                  HeaderImage(),
                ],
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate((context, position) {
                return _newsItemRow (context);
              }, childCount: 10),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _newsItemRow (BuildContext context) {
  return Padding(
    padding: const EdgeInsets.only(right: 20, left: 20),
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: InkWell(
          onTap: (){
            Navigator.push(context, PageRouteBuilder(
              pageBuilder: (BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation) {
                return SingleNewsPage();
              },
              transitionsBuilder: (BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
                return SlideTransition(
                  position: new Tween<Offset>(
                    begin: const Offset(-1.0, 0.0),
                    end: Offset.zero,
                  ).animate(animation),
                  child: new SlideTransition(
                    position: new Tween<Offset>(
                      begin: Offset.zero,
                      end: const Offset(-1.0, 0.0),
                    ).animate(secondaryAnimation),
                    child: child,
                  ),
                );
              },
            ),
            );
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'HeadLine',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      'Llorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor adipiscing elit, sed do eiusmod tempor.',
                      maxLines: 4,
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                        height: 1.25,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      '10.23am | Wed, Jan 8',
                      style: TextStyle(color: Colors.grey, fontSize: 8),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 100,
              ),
              Expanded(
                child: Container(
                  width: 105,
                  height: 110,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: ExactAssetImage('assets/img/12.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
