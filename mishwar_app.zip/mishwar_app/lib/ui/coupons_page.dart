import 'package:flutter/material.dart';
import 'package:mishwar_app/shared/header_image.dart';

class CouponsPage extends StatefulWidget {
  CouponsPage({Key key}) : super(key: key);

  @override
  _CouponsPageState createState() => _CouponsPageState();
}

class _CouponsPageState extends State<CouponsPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(240, 240, 240, 1),
        body: CustomScrollView(
          slivers: <Widget>[
            SliverFixedExtentList(
              itemExtent: 160,
              delegate: SliverChildListDelegate(
                [
                  HeaderImage(),
                ],
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate((context, position) {
                return _couponItemRow();
              }, childCount: 10),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _couponItemRow() {
  return Card(
    child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
            child: Container(
              width: 100,
              height: 60,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: ExactAssetImage('assets/img/12.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SizedBox(
            width: 20,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Chicken Spot',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  '0123 Road',
                  style: TextStyle(color: Colors.grey, fontSize: 8),
                ),
                SizedBox(
                  height: 2.5,
                ),
                Text(
                  'Jerusalem, IL',
                  style: TextStyle(color: Colors.grey, fontSize: 8),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 20,
          ),
          Expanded(
            child: RawMaterialButton(
              constraints: BoxConstraints(),
              padding: EdgeInsets.fromLTRB(14, 4, 14, 4),
              elevation: 0,
              onPressed: () {},
              fillColor: Color(0xFFF2F2F2),
              shape: StadiumBorder(),
              child: Text(
                'SHOP',
                style: TextStyle(
                  color: Colors.blueAccent.shade700,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
