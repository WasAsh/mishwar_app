import 'package:flutter/material.dart';
import 'package:mishwar_app/shared/header_image.dart';
import 'package:mishwar_app/shared/nav_drawer.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:flutter_icons/flutter_icons.dart';


class LandingPage extends StatefulWidget {
  LandingPage({Key key}) : super(key: key);
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController _searchController = TextEditingController();

    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(240, 240, 240, 1),
        drawer: NavigationDrawer(),
        body: Stack(
          children: <Widget>[
            ListView(
              children: <Widget>[
                HeaderImage(),
                Padding(
                  padding: EdgeInsets.only(
                    left: 18,
                    right: 18,
                  ),
                  child: Container(
                    padding: EdgeInsets.only(top: 10),
                    width: 330,
                    height: 45,
                    child: TextField(
                      controller: _searchController,
                      decoration: InputDecoration(
                        labelText: "Search",
                        hintText: "Search",
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20),
                  child: Text(
                    'What are you feeling today ?',
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    style: TextStyle(
                      fontSize: 43,
                      color: Color.fromRGBO(141, 141, 141, 1),
                    ),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    ListTile(
                      onTap: () {
                        _singleCategoryPage(context);
                      },
                      title: Text(
                        'Dining',
                        style: TextStyle(
                          color: Color.fromRGBO(158, 158, 158, 1),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18,
                        right: 18,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                    ListTile(
                      onTap: () {},
                      title: Text(
                        'Bars',
                        style: TextStyle(
                          color: Color.fromRGBO(158, 158, 158, 1),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18,
                        right: 18,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                    ListTile(
                      onTap: () {},
                      title: Text(
                        'Parking',
                        style: TextStyle(
                          color: Color.fromRGBO(158, 158, 158, 1),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18,
                        right: 18,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                    ListTile(
                      onTap: () {},
                      title: Text(
                        'Medicine',
                        style: TextStyle(
                          color: Color.fromRGBO(158, 158, 158, 1),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18,
                        right: 18,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                    ListTile(
                      onTap: () {},
                      title: Text(
                        'Clothing',
                        style: TextStyle(
                          color: Color.fromRGBO(158, 158, 158, 1),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18,
                        right: 18,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                    ListTile(
                      onTap: () {},
                      title: Text(
                        'Gas Stations',
                        style: TextStyle(
                          color: Color.fromRGBO(158, 158, 158, 1),
                          fontSize: 16,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18,
                        right: 18,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void _singleCategoryPage(BuildContext context) {
  double rating = 5;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: new BoxDecoration(
        color: Colors.grey.shade300,
        borderRadius: new BorderRadius.only(
          topLeft: const Radius.circular(25.0),
          topRight: const Radius.circular(25.0),
        ),
      ),
      child: ListView(
        padding: EdgeInsets.only(left: 20, right: 20),
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: 30),
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 190,
              decoration: BoxDecoration(
                image: DecorationImage(
                    fit: BoxFit.fill,
                    image: ExactAssetImage('assets/img/12.jpg')),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Chicken Spot',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: <Widget>[
                        Text(
                          'Open ',
                          style: TextStyle(fontSize: 12, color: Colors.green),
                        ),
                        Text(
                          '.',
                          style: TextStyle(fontSize: 12),
                        ),
                        Text(
                          ' Closes 11PM',
                          style: TextStyle(
                              fontSize: 12, color: Colors.grey.shade500),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      '0123 Something Road',
                      style:
                          TextStyle(fontSize: 12, color: Colors.grey.shade500),
                    ),
                    Text(
                      'Jerusalem, IL 20939',
                      style:
                          TextStyle(fontSize: 12, color: Colors.grey.shade500),
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Text(
                          '4.2',
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                        SizedBox(
                          width: 2,
                        ),
                        SmoothStarRating(
                          allowHalfRating: false,
                          onRatingChanged: (value) {
                            rating = value;
                          },
                          starCount: 5,
                          rating: rating,
                          size: 20.0,
                          color: Colors.amber,
                          borderColor: Colors.amber,
                          spacing: 0.0,
                        ),
                        SizedBox(
                          width: 2,
                        ),
                        Text(
                          '7,930',
                          style: TextStyle(color: Colors.grey.shade500),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 50 , left: 50),
                      child: Row(
                        children: <Widget>[

                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}
