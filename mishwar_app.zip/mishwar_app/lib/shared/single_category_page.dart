import 'package:flutter/material.dart';
import 'package:mishwar_app/shared/header_image.dart';



class SingleCategoryPage extends StatefulWidget {
  @override
  _SingleCategoryPageState createState() => _SingleCategoryPageState();
}

class _SingleCategoryPageState extends State<SingleCategoryPage> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          height: MediaQuery.of(context).size.height / 3,
          child: HeaderImage(),

          //  loading !!
        ),
      ],
    );
  }
}
