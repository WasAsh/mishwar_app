
class NavDrawer {
  String title ;
  Function destination ;


  NavDrawer(this.title, this.destination);


}