import 'package:flutter/material.dart';
import 'package:mishwar_app/shared/bottom_bar.dart';
import 'package:mishwar_app/shared/single_category_page.dart';
import 'package:mishwar_app/ui/login_page.dart';
import 'package:mishwar_app/ui/shop_page.dart';
import 'package:mishwar_app/shared/single_news_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.white,
      ),
      home: BottomBar(),
    );
  }
}





//import 'package:flutter/material.dart';
//import 'package:mishwar_app/shared/bottom_bar.dart';
//import 'package:mishwar_app/ui/landing_page.dart';
//import 'package:mishwar_app/ui/login_page.dart';
//
//
//main(){
//runApp(MishwarApp()) ;
//}
//
//
//class MishwarApp extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    return MaterialApp(
//      debugShowCheckedModeBanner: false,
//      home: LandingPage(),
//    );
//  }
//}
